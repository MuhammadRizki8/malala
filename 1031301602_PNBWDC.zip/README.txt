Link GitHub : https://github.com/MuhammadRizki8/malala
Link Deployment : malala.vercel.app